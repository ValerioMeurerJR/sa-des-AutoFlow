type CreateUserType = {
    name: string,
    email: string,
    password: string,
    birthDate: string
}