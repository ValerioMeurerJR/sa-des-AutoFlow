type LoginType = {
    email: string,
    password: string,
}