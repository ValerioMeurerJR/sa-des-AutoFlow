
export default function Dashboard() {
    return (
        <main>
            <h1>Dashboard</h1>
        </main>
    )
}